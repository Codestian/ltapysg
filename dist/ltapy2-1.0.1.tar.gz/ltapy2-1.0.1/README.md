# Ltapy
## Asynchronous python library to interact with LTA's Datamall API.
This library is primarily designed for the **Land Transport Authority integration** in Home Assistant.

### Installation
`$ pip install ltapy`